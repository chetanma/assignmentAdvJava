package com.cybage;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //load context.xml file
        ApplicationContext ctx=new ClassPathXmlApplicationContext("context.xml");
        //get bean 
        Question question=(Question)ctx.getBean("q");
        question.displayInfo();
       
    }
}
