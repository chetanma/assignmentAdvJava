package com.cybage;

import java.util.Iterator;
import java.util.List;
/*Create a Spring Core application for Forum where One question can have multiple answers. 
1. Question.java 2. applicationContext.xml 3. Test.java 
Use any collection element to store the multiple answer.(list,set,prop*/
public class Question {
	private int id;
	private String name;
	private List<String> answers;
	public Question() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Question(int id, String name, List<String> answers) {
		super();
		this.id = id;
		this.name = name;
		this.answers = answers;
	}
	
	public void displayInfo()
	{
		System.out.println(id +" "+name);
		System.out.println("Answers are:");
		Iterator<String> iterator=answers.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
			
		}
	}
	
	
	
}
