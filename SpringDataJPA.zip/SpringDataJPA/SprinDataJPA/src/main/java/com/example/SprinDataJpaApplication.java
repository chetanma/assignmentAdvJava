package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.model.Person;
import com.example.repository.PersonRepository;

@SpringBootApplication
public class SprinDataJpaApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SprinDataJpaApplication.class, args);
	}

	@Autowired
	PersonRepository pr;
	@Override
	public void run(String... args) throws Exception {
		/*Create a PersonRepository(Id,Name,Address,ContactNo,Age) to perform the following operations :
		1.Save the perosn record
		2. Search a record by PK
		3. Delete a record
		4. Update the record.*/
		
		//Save the perosn record...
		Person person1 = new Person(1,"Ramesh","Pune",40);
		Person person2 = new Person(2,"Sanjay","Mumbai",45);		
		pr.save(person1);
		pr.save(person2);
		
		//Search a record by PK...
		System.out.println("Record Found-->"+pr.findById(2));
		
		//Delete a record...
		pr.delete(person2);
		
		//Update the record...
		Person p = pr.findById(1).get();
		p.setName("Suresh");		
		pr.save(p);		
	}
}