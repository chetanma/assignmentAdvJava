package com.cybage;

public class Rectangle implements Shape {

	private int width;
	private int breadth;
	
	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

	public float getArea() {
		
		return width * breadth;
	}

	public float getPerimeter() {
		
		return (width  + breadth);
	}
}
