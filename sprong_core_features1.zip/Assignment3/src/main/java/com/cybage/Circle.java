package com.cybage;

public class Circle implements Shape {	

	private int radius;
	
	
		public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

		public float getArea() {
			return (float)(3.14 * radius *radius);
		}

		public float getPerimeter() {
			
			return (float)(2*3.14* radius);
		}
	

}
