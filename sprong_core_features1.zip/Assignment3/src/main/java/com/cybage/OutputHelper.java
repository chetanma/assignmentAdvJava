package com.cybage;

public class OutputHelper  {
Shape shape;


    
    public void getShape() {
	 System.out.println(shape.getArea());;
	 System.out.println(shape.getPerimeter());
	 }

    public void setShape(Shape shape) {
	this.shape = shape;
    }

	
}
