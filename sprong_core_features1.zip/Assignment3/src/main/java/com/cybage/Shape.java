package com.cybage;
/*Create a simple spring maven application to create
 *  two beans Circle and Rectangle which are implementing Shape 
 *  interface which has area and perimeter abstract methods, 
 *  calculate both the area and perimeter
 *  of the shapes by coding through interfaces concept. */
public interface Shape {

	abstract float getArea();
	abstract float getPerimeter();
}
