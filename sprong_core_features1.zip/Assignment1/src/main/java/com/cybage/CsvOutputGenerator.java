package com.cybage;

public class CsvOutputGenerator implements IOutputGenerator {

	

	    public void generateOutput(){
	        System.out.println("Csv Output Generator");
	    }
	

}
