package com.cybage;

public interface IOutputGenerator {

	public void generateOutput();
}
