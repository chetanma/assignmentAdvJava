package com.cybage;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //load context.xml file
        ApplicationContext ctx=new ClassPathXmlApplicationContext("context.xml");
        //get bean 
        Employee emp=(Employee)ctx.getBean("e1");
        System.out.println(emp.toString());
        Employee emp1=(Employee)ctx.getBean("e2");
        System.out.println(emp1.toString());
    }
}
