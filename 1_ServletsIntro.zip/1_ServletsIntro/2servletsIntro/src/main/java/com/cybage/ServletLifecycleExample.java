package com.cybage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class ServletLifecycleExample extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
	public void init(ServletConfig config) throws ServletException {
		// initializing the servlet... 
		System.out.println("Servlet Initialized !!!");
	}
	
	//method to handle requests coming from the client which later invokes doGet(), doPost()...
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");        
        PrintWriter out = response.getWriter();
        out.println("Servlet called from index.jsp page!");
	}
	
	public void destroy() {
		System.out.println("Servlet destroyed !!!");
	}

	

}
